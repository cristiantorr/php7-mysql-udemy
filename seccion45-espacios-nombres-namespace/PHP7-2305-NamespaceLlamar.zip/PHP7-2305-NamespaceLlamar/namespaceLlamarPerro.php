<?php  
namespace Animal\Perro\salchicha;

const NOMBRE = "Canelita";
function comer(){
	print "Estoy comiendo, Canelita<br>";
}
class Pasear{
	static function paseo(){
		print "Estoy paseando, Canelita<br>";
	}
}
?>