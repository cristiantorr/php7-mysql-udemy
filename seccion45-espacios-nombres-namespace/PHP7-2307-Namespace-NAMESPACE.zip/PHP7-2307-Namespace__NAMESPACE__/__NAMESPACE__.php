<?php
namespace Perro; 
//print "***".namespace."***";
class Ladrar{
	function __construct()
	{
		print "guau, guau<br>";
	}
}

$perro = new namespace\Ladrar();


?>