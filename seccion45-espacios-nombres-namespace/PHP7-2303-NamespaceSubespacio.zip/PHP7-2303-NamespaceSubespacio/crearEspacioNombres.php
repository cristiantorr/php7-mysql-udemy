<?php  
namespace Perro;

const NOMBRE = "Lazzy";
class MiPerro { /*...*/}
function pasearAlPerro() { /*******/ }

?>