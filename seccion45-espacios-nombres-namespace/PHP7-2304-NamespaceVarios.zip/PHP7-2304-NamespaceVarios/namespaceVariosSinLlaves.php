<?php  
namespace Perro;
	const NOMBRE = "Lazzy";
	class Comer{/************/}
	function pasear(){/***********/}

namespace Gato;
	const NOMBRE = "Garfield";
	class Comer{/************/}
	function pasear(){/***********/}
?>