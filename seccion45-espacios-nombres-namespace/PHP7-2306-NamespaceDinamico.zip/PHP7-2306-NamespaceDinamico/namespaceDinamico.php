<?php
namespace miNamespace;

class miClase{
	function __construct(){
		print "Hola desde la funcion constructora<br>";
	}
}
function miFuncion(){
	print "Hola desde la función<br>";
}
const miConstante = "Hola<br>";

//dinamica
$a = "\miNamespace\miClase";
$clase = new $a;
$b = "\miNamespace\miFuncion";
$b();
print constant("\miNamespace\miConstante");
?>