<!DOCTYPE html>
<html>
<head>
	<title>Estadisticas</title>
	<meta charset="utf-8"/>
	<?php
		class BaseDatos extends SQLite3{
			function __construct()
			{
				$this->open("libros.db");
			}
		}

		$db = new BaseDatos();
		if (!$db) {
			echo "<p>ERROR al abrir la base de datos 'libros'</p>";
		}
	?>
</head>
<body>
<table>
<?php	
	$sql = "SELECT autor, count(*) as num  FROM libros GROUP BY autor  ORDER BY num DESC;";
	$ret = $db->query($sql);
	//
	echo "<tr>";
	echo "<th>". $columna. "</td>";
	echo "<th>num</td>";
	echo "</tr>";
	while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
		echo "<tr>";
		echo "<td>". $row['AUTOR'] . "</td>";
		echo "<td>". $row['num'] ."</td>";
		echo "</tr>";
	}
} 
?>
</table>
</body>
</html>