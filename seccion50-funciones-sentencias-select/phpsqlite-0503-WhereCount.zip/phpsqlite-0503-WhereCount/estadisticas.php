<!DOCTYPE html>
<html>
<head>
	<style>
		body{
			width:350px;
			margin:0 auto;
		}
		table{
			width:100%;
		}
	</style>
	<title>Estadisticas</title>
	<meta charset="utf-8"/>
	<?php
		class BaseDatos extends SQLite3{
			function __construct()
			{
				$this->open("libros.db");
			}
		}

		$db = new BaseDatos();
		if (!$db) {
			echo "<p>ERROR al abrir la base de datos 'libros'</p>";
		}
	?>
</head>
<body>
<form action="estadisticas.php" method="get">
<select name="col" id="col">
	<option value="0">Selecciona una columna</option>
	<option value="1">Por autor</option>
	<option value="2">Por editorial</option>
	<option value="3">Por año</option>
</select>
<select name="filtro" id="filtro">
	<option value="0">Selecciona filtro</option>
	<option value="1">Mayor a 1</option>
	<option value="2">Mayor a 2</option>
	<option value="3">Mayor a 3</option>
</select>
<input type="submit" value="Enviar">
</form>
<table>
<?php
if (isset($_GET["col"])) {
	$col = $_GET["col"];
	if($col==0) $columna="";
	if($col==1) $columna="autor";
	if($col==2) $columna="editorial";
	if($col==3) $columna="anio";
}
if (isset($_GET["filtro"])) {
	$filtro = $_GET["filtro"];
}
if($col>0){
	$sql = "SELECT count(*) as num FROM libros";
	$ret = $db->query($sql);
	$num = $ret->fetchArray();
	$numLibros = $num['num'];
	echo "<br>";
	echo "Tenemos ".$numLibros." libros en la base de datos<br>";
	echo "<br>";
	$sql = "SELECT ".$columna." as columna, count(*) as num  FROM libros GROUP BY ".$columna." HAVING num > ".$filtro." ORDER BY num DESC;";
	$ret = $db->query($sql);
	//
	echo "<tr>";
	echo "<th>". $columna. "</td>";
	echo "<th>num</td>";
	echo "</tr>";
	while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
		echo "<tr>";
		echo "<td>". $row['columna'] . "</td>";
		echo "<td>". $row['num'] ."</td>";
		echo "</tr>";
	}
} else {
	echo "Debe de seleccionar una columna";
}
} 
?>
</table>
</body>
</html>