<?php
	class BaseDatos extends SQLite3{
		function __construct()
		{
			$this->open("libros.db");
		}
	}

	$db = new BaseDatos();
	if ($db) {
		echo "<p>La base de datos 'libros' se abrio en forma exitosa</p>";
	} else {
		echo "<p>ERROR al abrir la base de datos 'libros'</p>";
	}

	$q = <<<sql
	CREATE TABLE libros
	(isdn int PRIMARY KEY
	NOMBRE text,
	AUTOR text,
	ANIO int,
	EDITORIAL text);
sql;
	echo $q;
?>