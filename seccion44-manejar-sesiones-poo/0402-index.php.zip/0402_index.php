<?php
require_once("clases.php");

$sesion = new Sesion();
if($sesion->estadoLogin()){
	header("location:inicio.php");
} else {
	header("location:login.php");
}
?>