<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Login</title>
</head>

<body>
<form action="inicioLogin.php" method="post">
Correo:
<input type="text" id="correo" name="correo"/><br>
<input type="submit" id="envia" name="envia" value="Entrar"/>
</form>
</body>
</html>