<?php
require_once("clases.php");
$sesion = new Sesion();
if($sesion->estadoLogin()==false){
	header("location:login.php");
	exit;	
}
?>
<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Inicio</title>
</head>

<body>
<h1>Bienvenid@ a la página: <?php print $sesion->getUsuario(); ?></h1>
</body>
</html>