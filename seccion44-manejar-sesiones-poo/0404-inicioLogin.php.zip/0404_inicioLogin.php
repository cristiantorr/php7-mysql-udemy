<?php
require_once("clases.php");
$sesion = new Sesion();
if(isset($_POST["correo"])){
	$usuario = $_POST["correo"];
	if(Usuarios::buscaUsuario($usuario)){
		$sesion->inicioLogin($usuario);
		header("location:inicio.php");
		exit;
	} else {
		header("location:login.php");
		exit;
	}
} else {
	header("location:login.php");
}


?>