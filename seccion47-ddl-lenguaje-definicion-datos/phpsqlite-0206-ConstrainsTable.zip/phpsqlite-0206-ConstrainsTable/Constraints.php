<?php
	class BaseDatos extends SQLite3{
		function __construct()
		{
			$this->open("libros.db");
		}
	}

	$db = new BaseDatos();
	if ($db) {
		echo "<p>La base de datos 'libros' se abrio en forma exitosa</p>";
	} else {
		echo "<p>ERROR al abrir la base de datos 'libros'</p>";
	}

	$q = <<<sql
	CREATE TABLE if not exists libros
	(id INTEGER PRIMARY KEY AUTOINCREMENT,
	NOMBRE    text NOT NULL,
	AUTOR     text NOT NULL,
	ANIO      int  DEFAULT 2001,
	EDITORIAL text DEFAULT "N.A.",
	PRECIO    real DEFAULT 0,
	FECHA	  text CURRENT_TIMESTAMP);
sql;
	$r = $db->exec($q);
	if ($r) {
		echo "<p>La tabla 'libros' se creo en forma exitosa</p>";
	} else {
		echo "<p>ERROR al crear la tabla 'libros'</p>";
	}
	//Drop table
	$q = "DROP TABLE if exists libros;";
	$r = $db->exec($q);
	if ($r) {
		echo "<p>La tabla 'libros' se borro en forma exitosa</p>";
	} else {
		echo "<p>ERROR al borrar la tabla 'libros'</p>";
	}
	$db->close();
?>