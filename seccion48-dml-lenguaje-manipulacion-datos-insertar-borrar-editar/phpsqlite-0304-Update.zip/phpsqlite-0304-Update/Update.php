<?php
	class BaseDatos extends SQLite3{
		function __construct()
		{
			$this->open("libros.db");
		}
	}

	$db = new BaseDatos();
	if ($db) {
		echo "<p>La base de datos 'libros' se abrio en forma exitosa</p>";
	} else {
		echo "<p>ERROR al abrir la base de datos 'libros'</p>";
	}
	//UPDATE
	$q = "UPDATE libros SET precio=5.55 WHERE ID=1";
	$r = $db->query($q);
	if ($r) {
		echo "<p>El registro se actualizó en forma exitosa</p>";
	} else {
		echo "<p>ERROR al actualizar la base de datos 'libros'</p>";
	}
	
	$sql =<<<sql
      SELECT * FROM libros;
sql;
	//
   $ret = $db->query($sql);
   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
      echo "ID = ". $row['id'] . "<br>";
      echo "Nombre = ". $row['NOMBRE'] ."<br>";
      echo "Autor = ". $row['AUTOR'] ."<br>";
      echo "Fecha = ". $row['FECHA'] ."<br>";
      echo "Año =  ".$row['ANIO'] ."<br>";
      echo "Precio =  ".$row['PRECIO'] ."<br><br>";
   }
   $db->close();
?>