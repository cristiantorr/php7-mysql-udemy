<!DOCTYPE html>
<html>
<head>
	<title>Alta de libro</title>
	<meta charset="utf-8"/>
	<style>
		body{ width:300px; margin:0 auto; }
		fieldset{ background: #ddd; }
		td{ text-align: right; }
		input{width: 100%;}
		table{width: 100%;}
		input[type=text]:focus{background: lightblue;}
		.rojo{color:red;}
	</style>
</head>
<body>
<form action="alta.php" method="post">
<fieldset>
<legend>Alta de libro</legend>
<table>
	<tr>
		<td><label for="nombre">* Titulo:</label></td>
		<td><input type="text" name="nombre" id="nombre"></td>
	</tr>
	<tr>
		<td><label for="autor">* Autor:</label></td>
		<td><input type="text" name="autor" id="autor"></td>
	</tr>
	<tr>
		<td><label for="anio">Año:</label></td>
		<td><input type="text" name="anio" id="anio"></td>
	</tr>
	<tr>
		<td><label for="editorial">Editorial:</label></td>
		<td><input type="text" name="editorial" id="editorial"></td>
	</tr>
	<tr>
		<td><label for="precio">Precio:</label></td>
		<td><input type="text" name="precio" id="precio"></td>
	</tr>
	<tr>
		<td></td>
		<td><input type="submit" name="enviar" id="enviar" value="Enviar"></td>
	</tr>
</table>
<a href="ABC01.php">Regresar</a>
</fieldset>
</form>
</body>
</html>