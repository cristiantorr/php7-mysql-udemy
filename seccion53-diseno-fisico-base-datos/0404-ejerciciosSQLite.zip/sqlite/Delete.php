<!doctype html>
<html>
	<head>
		<title>ABC Libros</title>
		<meta charset="utf-8"/>
		<?php
			class BaseDatos extends SQLite3{
				function __construct()
				{
					$this->open("libros.db");
				}
			}

			$db = new BaseDatos();
			if (!$db) {
				echo "<p>ERROR al abrir la base de datos 'libros'</p>";
			}
		?>
	</head>
	<body>
		<?php
			$sql ="DELETE from libros where ID=7;";
		   $ret = $db->exec($sql);
		   if(!$ret){
		     echo $db->lastErrorMsg();
		   } else {
		      echo $db->changes(), " Record deleted successfully<br>";
		   }
			//abc crud
			$sql ="SELECT * FROM libros;";
			//
		   $ret = $db->query($sql);
		   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
		      echo "ID = ". $row['id'] . "<br>";
		      echo "Nombre = ". $row['NOMBRE'] ."<br>";
		      echo "Autor = ". $row['AUTOR'] ."<br>";
		      echo "Fecha = ". $row['FECHA'] ."<br>";
		      echo "Año =  ".$row['ANIO'] ."<br>";
		      echo "Precio =  ".$row['PRECIO'] ."<br><br>";
		   }
		   $db->close();
		?>
	</body>
</html>