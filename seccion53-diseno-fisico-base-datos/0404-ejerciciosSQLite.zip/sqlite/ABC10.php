<!doctype html>
<html>
	<head>
	<style>
		body{
			width:960px;
			margin:0 auto;
		}
		table{
			width: 100%;
		}
		th{background: blue; color:white;}
		tr:nth-child(odd){background:gray;}
		h1{text-align: center;}
		.der{text-align: right;}
		.cen{text-align: center;}
		th a{ color: white; text-decoration: none; }
	</style>
		<title>ABC Libros</title>
		<meta charset="utf-8"/>
		<?php
			class BaseDatos extends SQLite3{
				function __construct()
				{
					$this->open("libros.db");
				}
			}

			$db = new BaseDatos();
			if (!$db) {
				echo "<p>ERROR al abrir la base de datos 'libros'</p>";
			}
		?>
		<script>
			function cambiaPagina(p) {
				window.open("ABC09.php?p="+p,"_self");
			}
		</script>
	</head>
	<body>
		<h1>Catálogo de libros</h1>
		<table><tr>
			<th>id</th>
			<th><a href="ABC09.php?col=nombre">Titulo</a></th>
			<th><a href="ABC09.php?col=autor">Autor</a></th>
			<th><a href="ABC09.php?col=anio">Año</a></th>
			<th><a href="ABC09.php?col=editorial">Editorial</a></th>
			<th><a href="ABC09.php?col=precio">Precio</a></th>
			<th><a href="ABC09.php?col=fecha">Fecha</a></th>
			<th>Modificar</th>
			<th>Borrar</th>
		</tr>
		<?php
		 	//Determinar los parámetros
			//Limitar la busqueda
			$TAMANO_PAGINA = 5;
			$PAGINAS_MAXIMAS = 5;
			//examinar la página a mostrar 
			if(isset($_GET["p"])){
				$pagina = $_GET["p"];
			} else {
				$pagina = 1;
			}
			//Determinamos el número de registros
			$inicio = ($pagina - 1) * $TAMANO_PAGINA;
			$rows = $db->query("SELECT COUNT(*) as libros FROM libros");
			$num = $rows->fetchArray();
			$numLibros = $num['libros'];
			//Cálculo el total de páginas
			$total_paginas = ceil($numLibros / $TAMANO_PAGINA);
			//
			//Filtros
			//
			$sql ="SELECT id, nombre, autor, editorial, anio, precio, datetime('now') FROM libros ";
			//Año
			if(isset($_GET['anio'])){
				$a = $_GET['anio'];
				if ($a!="todos") {
					$sql .= "WHERE anio=".$a." ";
				} 
			}
			//Par o impar
			if(isset($_GET['par'])){
				$a = $_GET['par'];
				if ($a!="todos") {
					if ($a=="par") {
						$sql .= "WHERE anio%2=0 ";
					} else {
						$sql .= "WHERE anio%2=1 ";
					}
				} 
			}
			//Autor
			if(isset($_GET['autor'])){
				$a = $_GET['autor'];
				if ($a!="todos") {
					$sql .= "WHERE ";
					$sql .= "autor like '%".$a."%' OR "; 
					$sql .= "editorial like '%".$a."%' OR ";
					$sql .= "anio like '%".$a."%' OR ";
					$sql .= "precio like '%".$a."%' OR ";
					$sql .= "fecha like '%".$a."%' OR "; 
					$sql .= "nombre like '%".$a."%' "; 
				} 
			}
			//Precio
			if(isset($_GET['precio'])){
				$a = $_GET['precio'];
				if ($a!="todos") {
					$sql .= "WHERE ";
					if ($a=='1') {
						$sql .= "precio < 199;"; 
					} else if ($a=='5') {
						$sql .= "precio >= 500;";
					} else {
						$sql .= "precio glob '".$a."??.*' ";
					}
				} 
			}
			//Orden
			if(isset($_GET['orden'])){
				$a = $_GET['orden'];
				$sql .= "ORDER BY anio ".$a." ";
			}
			//Ordenar por columna
			if(isset($_GET['col'])){
				$a = $_GET['col'];
				$sql .= "ORDER BY ".$a." ASC ";
			}
			//LIMIT
			$sql .= "LIMIT ".$TAMANO_PAGINA." OFFSET ".$inicio.";";
		   $ret = $db->query($sql);
		   //
		   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
		   	echo "<tr>";
		      echo "<td class='cen'>". $row['id'] . "</td>";
		      echo "<td>". $row['NOMBRE'] ."</td>";
		      echo "<td>". $row['AUTOR'] ."</td>";
		      echo "<td class='cen'>".$row['ANIO'] ."</td>";
		      echo "<td>".$row['EDITORIAL'] ."</td>";
		      echo "<td class='der'>".number_format($row['PRECIO'],2) ."</td>";
		      echo "<td class='cen'>". $row['FECHA'] ."</td>";
		      //Modificar
		      echo "<td class='cen'>";
		      echo "<a href='modificar.php?id=".$row['id']."'>";
		      echo "<img src='imagenes/lapiz.png' width='16'/>";
		      echo "</a></td>";
		      //Borrar
		      echo "<td class='cen'>";
		      echo "<a href='borrar.php?id=".$row['id']."'>";
		      echo "<img src='imagenes/borrar.png' width='16'/>";
		      echo "</a></td>";
		      echo "</tr>";
		   }
		   //
		   //abc crud
			$sql ="SELECT DISTINCT anio FROM libros ORDER BY anio DESC;";
			//
		   $ret = $db->query($sql);
		   echo "<form action='ABC09.php' method='get'>";
		   echo "<select id='anio' name='anio'>";
		   echo "<option value='todos'>Todos los años</option>";
		   while($row = $ret->fetchArray(SQLITE3_ASSOC) ){
		   	echo "<option value='".$row["ANIO"]."'>";
		    echo $row['ANIO'];
		    echo "</option>";
		   }
		   echo "</select>";
		   echo "<select id='orden' name='orden'>";
		   echo "<option value='ASC'>Ascendente</option>";
		   echo "<option value='DESC'>Descendente</option>";
		   echo "</select>";
		   echo "<input type='submit' value='Filtrar'/>";
		   echo "</form>";
		   //
		   echo "<br>";
		   echo "<form action='ABC09.php' method='get'>";
		   echo "<select id='par' name='par'>";
		   echo "<option value='todos'>Todos los años</option>";
		   echo "<option value='par'>Años pares</option>";
		   echo "<option value='impar'>Años impares</option>";
		   echo "</select>";
		   echo "<input type='submit' value='Filtrar'/>";
		   echo "</form>";
		   //Nombre
		   echo "<br>";
		   echo "<form action='ABC09.php' method='get'>";
		   echo "<input type='search' name='autor' id='autor'>";
		   echo "<input type='submit' value='Filtrar'/>";
		   echo "</form>";
		   //
		   echo "<br>";
		   echo "<form action='ABC09.php' method='get'>";
		   echo "<select id='precio' name='precio'>";
		   echo "<option value='todos'>Todos los años</option>";
		   echo "<option value='1'>Entre 0 y 199</option>";
		   echo "<option value='2'>Entre 200 y 299</option>";
		   echo "<option value='3'>Entre 300 y 399</option>";
		   echo "<option value='4'>Entre 400 y 499</option>";
		   echo "<option value='5'>Mayor a 500</option>";
		   echo "</select>";
		   echo "<input type='submit' value='Filtrar'/>";
		   echo "</form>";
		   $db->close();
		?>
		</table>
		<div>
			<?php
				if ($total_paginas>$PAGINAS_MAXIMAS) {
					if ($pagina==$total_paginas) {
						$fin = $total_paginas;
					} else {
						$inicio = $pagina;
						$fin = ($inicio-1)+$PAGINAS_MAXIMAS;
						if($fin>$total_paginas) $fin = $total_paginas;
					}
					if ($inicio!=1) {
						print "<button type='button' onclick='cambiaPagina(1)'>Primero</button>";
						print "<button type='button' onclick='cambiaPagina(".($pagina-1)."'>Ant.</button>";
					}
				} else {
					$inicio = 1;
					$fin = $total_paginas;
				}
				for ($i=$inicio; $i <= $fin ; $i++) { 
					print "<button type='button' ";
					if($i==$pagina) print "active ";
					print "onclick='cambiaPagina(".$i.")'>".$i."</button>";
				}
				if ($total_paginas>$PAGINAS_MAXIMAS && $pagina!=$total_paginas) {
						print "<button type='button' onclick='cambiaPagina(".($pagina+1).")'>Sig.</button>";
						print "<button type='button' onclick='cambiaPagina(".$total_paginas.")'>Último</button>";
					}
			?>
		</div>
		<a href="alta.php">Dar de alta un título</a>
	</body>
</html>