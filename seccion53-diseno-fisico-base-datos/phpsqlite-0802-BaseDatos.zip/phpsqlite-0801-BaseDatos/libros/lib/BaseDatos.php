<?php
class BaseDatos extends SQLite3{
	function __construct()
	{
		$this->open("libros.db");

		$q = <<<sql
		CREATE TABLE IF NOT EXISTS libros
		(id integer PRIMARY KEY AUTOINCREMENT,
		NOMBRE text,
		PAG integer,
		ANIO integer,
		idEDITORIAL integer);
sql;
		//echo "<p>".$q."</p>";
		$r = $this->query($q);
		if (!$r) {
			echo "<p>ERROR al crear la tabla 'libros'</p>";
		}

		//Crear la tabla intermedia
		$q = <<<sql
		CREATE TABLE IF NOT EXISTS librosAutores
		(id integer PRIMARY KEY AUTOINCREMENT,
		idLibro integer,
		idAutor integer);
sql;
		//echo "<p>".$q."</p>";
		$r = $this->exec($q);
		if (!$r){
			echo "<p>ERROR al crear la tabla 'librosAutores'</p>";
		}

		//Crear la tabla autores
		$q = <<<sql
		CREATE TABLE IF NOT EXISTS autores
		(id integer PRIMARY KEY AUTOINCREMENT,
		nombre string,
		pais int,
		fechaNac string,
		nobel boolean);
sql;
		//echo "<p>".$q."</p>";
		$r = $this->exec($q);
		if (!$r){
			echo "<p>ERROR al crear la tabla 'autores'</p>";
		}

		//Crear la tabla editoriales
		$q = <<<sql
		CREATE TABLE IF NOT EXISTS editoriales
		(id integer PRIMARY KEY AUTOINCREMENT,
		nombre string,
		pais text);
sql;
		//echo "<p>".$q."</p>";
		$r = $this->exec($q);
		if (!$r) {
			echo "<p>ERROR al crear la tabla 'editoriales'</p>";
		}
	}//de la constructor
}// de la clase
?>